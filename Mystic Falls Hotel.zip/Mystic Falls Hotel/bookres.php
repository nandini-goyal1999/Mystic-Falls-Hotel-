<?php
include('db.php');
header("Refresh:2;url=booktable.php");
if(isset($_POST['form-submit']))
				{
					$day =$_POST['day'];
					$hour= $_POST['hour'];
					$name = $_POST['name'];
                    $phone = $_POST['phone'];
                    $no_of_person = $_POST['persons'];
                   $sql = "INSERT INTO res_table(day, time, name, phone, no_of_person) VALUES ('$day','$hour','$name','$phone','$no_of_person')" ;
                   
				   if(mysqli_query($con,$sql)){
                         echo ' <script> alert("Table booking request sent");</script>';
                   }
 
                }  

?>              
                            
                            
                            
                     
                     
                          
                     
					
                    
				
