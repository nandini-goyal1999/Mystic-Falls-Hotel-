<?php
 session_start();
$con = mysqli_connect("localhost","root","","hotel") or die(mysql_error());
$_SESSION['email'];
$_SESSION['pass'];
?>