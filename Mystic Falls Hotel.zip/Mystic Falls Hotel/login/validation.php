<?php
 session_start();
 $con = mysqli_connect("localhost","root","","hotel") or die(mysql_error());

$password=$_POST['pass'];
$email=$_POST['email'];
$s="select * from register where email= '$email'  && pass='$password'";
$result=  mysqli_query($con, $s);
$num=  mysqli_num_rows($result);
if($num==1){

	$_SESSION['email']=$email;
    $_SESSION['pass']=$password;
	echo ' <script> alert("logged in Successfully");</script>';
    header("Refresh:2;url=../index.php");
}else{
	 
   
    echo ' <script> alert("invalid credentials");</script>';
     }
?>
