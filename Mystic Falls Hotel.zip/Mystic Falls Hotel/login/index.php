
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>LOGIN HERE</title>
        <link href="stylelog.css" rel="stylesheet" type="text/css">
    </head>
    <body style= "background:url(../images/photos/2.jpg) ; background-size:cover">
    <h1 style= "color:white ; padding:70px ; font-size:4vh ">Login to your Account</h1>
        <div class="wrapper">
            <h1>Sign In</h1>
            <form method="post" action="validation.php">
                <input type="email" name="email" placeholder="Email" required>
                <input type="password" name="pass" placeholder="Password" required>
                <button type="submit" name="submit" class="submit-btn"> Login</button>
        
                
                
            </form>
            <div class="bottom-text">
                <input type="checkbox" name="remember" checked="checked"> Remember me
               <a href="#">Forgot Password ?</a>
            </div>
            <ul style="color:white; border: 1px solid transparent; padding:5px; transition: 0.6s ease"><li> <a href="register-form.php">REGISTER</a></li></ul>
        </div>
        <div id="overlay-area"></div>
        

    </body>
</html>