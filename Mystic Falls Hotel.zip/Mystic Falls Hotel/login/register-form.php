<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "hotel";
    //create connection
    $con = new mysqli($servername, $username, $password, $dbname);
    
    $fname="";
    $lname="";
    $ccode="";
    $Mnumber="";
    $email="";
    $pass="";
    $bdate="";
    $country="";
    $gender="";
    $msg="";
    if(isset($_POST['submit'])){
        $fname=$_POST['Fname'];
        $lname=$_POST['Lname'];
        $ccode=$_POST['ccode'];
        $Mnumber=$_POST['Mnumber'];
        $email=$_POST['email'];
        $pass=$_POST['pass'];
        $bdate=$_POST['bdate'];
        $country=$_POST['country'];
        $gender=$_POST['gender'];
        $sql = "INSERT INTO  register(Fname,Lname,Countrycode,Mnmber,email,pass,bdate,country,gender) VALUES ('$fname','$lname','$ccode','$Mnumber','$email','$pass','$bdate','$country','$gender')";//echo $sql;exit;
        if(mysqli_query($con,$sql)){
            header('location:?msg=success');
        }
        else{
            header('location:?msg=failed');
        }
    }
    if(isset($_GET['msg']) && $_GET['msg']=='success'){
        $msg = "<p style='color: #fff;
        z-index: 9999999;
        font-weight: 900;
        font-size: 21px;
        background: #34b709;
        margin: 2% 33% 0;
        width: 31%;
        text-align: center;
        border-radius: 30px;
        padding: 0.6% 1%;
        box-shadow: 0 0 10px #000;
        text-shadow: 0 0 3px #000;'><i class='fa fa-check' style='margin:auto 3% auto -3%'></i>Registration Successful!</p>";
    }
    if(isset($_GET['msg']) && $_GET['msg']=='failed'){
        $msg = "<p style='color: #fff;
        z-index: 9999999;
        font-weight: 900;
        font-size: 21px;
        background: #bf0c0c;
        margin: 2% 30% 0;
        width: 37%;
        text-align: center;
        border-radius: 30px;
        padding: 0.6% 1%;
        box-shadow: 0 0 10px #000;
        text-shadow: 0 0 3px #000;'><i class='fa fa-times' style='margin:auto 2% auto -2%'></i>Registration Failed!... Please Try Again!</p>";
    }

?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Registration Form </title>
        <link href="stylereg.css" rel="stylesheet" type="text/css">
    </head>
    <body style="background:url(../images/photos/2.jpg); background-size:cover">
    <?php echo $msg;?>
        <div class="register">
            <h2> Register Here</h2>
       <form method="post" id="register" action="">
           
           <label> First Name : </label>
           <input type="text" name="Fname" id="name"
           placeholder="Enter your first name" required><br><br>
           <label> Last Name : </label>
           <input type="text" name="Lname" id="name"
           placeholder="Enter your last name" required><br><br>
           <label> Mobile Number :</label>
           <select id="ph" name="ccode">
               <option>+91</option>
               <option>+92</option>
               <option>+93</option>
               <option>+94</option>
               <option>+95</option>
           </select>
           <input type="number" name="Mnumber" id="num"
           placeholder="Enter your Mobile number" required><br><br>
           <label> Email : </label>
           <input type="email" name="email" id="name"
           placeholder="Enter your Email" required><br><br>
           <label> Password :</label>
           <input type="password" name="pass" id="name"
           placeholder="Enter your password" required><br><br>
           <label> DOB :</label>
           <input type="date" name="bdate" id="name"
           placeholder="Enter your Date of birth" required><br><br>
           <label> Country :</label>
           <select id="country" name="country">
               <option>India</option>
               <option>USA</option>
               <option>Canada</option>
               <option>Japan</option>
               <option>other</option>
            </select><br><br>
          <label> Gender :</label>
           <select name="gender">
               <option>Male</option>
               <option>Female</option>
               <option>Others</option>
           </select><br><br>
           <input type="submit" name="submit" value="Submit" id="sub">
       </form> 
    </div>

    </body>
</html>