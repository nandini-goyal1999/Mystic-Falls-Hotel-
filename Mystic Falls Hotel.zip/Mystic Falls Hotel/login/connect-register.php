<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "websiteuserdata";
    //create connection
    $con = new mysqli($servername, $username, $password, $dbname);
    
    $fname="";
    $lname="";
    $ccode="";
    $Mnumber="";
    $email="";
    $pass="";
    $bdate="";
    $country="";
    $gender="";
    $msg="";
    if(isset($_POST['submit'])){
        $fname=$_POST['Fname'];
        $lname=$_POST['Lname'];
        $ccode=$_POST['ccode'];
        $Mnumber=$_POST['Mnumber'];
        $email=$_POST['email'];
        $pass=$_POST['pass'];
        $bdate=$_POST['bdate'];
        $country=$_POST['country'];
        $gender=$_POST['gender'];
        $sql = "INSERT INTO  register(Fname,Lname,Countrycode,Mnmber,email,pass,bdate,country,gender) VALUES ('$fname','$lname','$ccode','$Mnumber','$email','$pass','$bdate','$country','$gender')";//echo $sql;exit;
        if(mysqli_query($con,$sql)){
            header('location:?msg=success');
        }
        else{
            header('location:?msg=failed');
        }
    }
    if(isset($_GET['msg']) && $_GET['msg']=='success'){
        $msg = "<p style='color: #fff;
        z-register-form: 9999999;
        font-weight: 900;
        font-size: 21px;
        background: #34b709;
        margin: 2% 33% 0;
        width: 31%;
        text-align: center;
        border-radius: 30px;
        padding: 0.6% 1%;
        box-shadow: 0 0 10px #000;
        text-shadow: 0 0 3px #000;'><i class='fa fa-check' style='margin:auto 3% auto -3%'></i>Registration Successful!</p>";
    }
    if(isset($_GET['msg']) && $_GET['msg']=='failed'){
        $msg = "<p style='color: #fff;
        z-register-form: 9999999;
        font-weight: 900;
        font-size: 21px;
        background: #bf0c0c;
        margin: 2% 30% 0;
        width: 37%;
        text-align: center;
        border-radius: 30px;
        padding: 0.6% 1%;
        box-shadow: 0 0 10px #000;
        text-shadow: 0 0 3px #000;'><i class='fa fa-times' style='margin:auto 2% auto -2%'></i>Registration Failed!... Please Try Again!</p>";
    }

?>
